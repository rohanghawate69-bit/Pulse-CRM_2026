"""
User Management Routes
GET    /api/v1/users
GET    /api/v1/users/deleted
POST   /api/v1/users
GET    /api/v1/users/{id}
PUT    /api/v1/users/{id}
DELETE /api/v1/users/{id}
POST   /api/v1/users/{id}/restore
DELETE /api/v1/users/{id}/permanent
POST   /api/v1/users/{id}/activate
POST   /api/v1/users/{id}/deactivate
POST   /api/v1/users/{id}/roles
"""
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.api.deps import CurrentUser, DBSession, invalidate_user_cache, require_permission, require_role
from app.schemas.common import PaginatedResponse, StandardResponse
from app.schemas.user import (
    ManagerAssignmentRequest,
    UserCreateRequest,
    UserResponse,
    UserRoleAssignRequest,
    UserUpdateRequest,
)
from app.services.user_service import UserService
from app.core.security import hash_password
from app.repositories.user_repository import UserRepository

router = APIRouter()


@router.get(
    "",
    response_model=StandardResponse[PaginatedResponse[UserResponse]],
    summary="List users",
    dependencies=[Depends(require_permission("user:read"))],
)
async def list_users(
    current_user: CurrentUser,
    db: DBSession,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    search: Optional[str] = Query(default=None),
) -> dict:
    svc = UserService(db)
    users, total = await svc.list_users(
        current_user.organization_id, search, page, page_size
    )
    paginated = PaginatedResponse.create(
        data=[UserResponse.from_orm_with_roles(u) for u in users],
        total=total,
        page=page,
        page_size=page_size,
    )
    return {"success": True, "message": "OK", "data": paginated}


@router.get(
    "/deleted",
    response_model=StandardResponse[PaginatedResponse[UserResponse]],
    summary="List archived (soft-deleted) users",
    dependencies=[Depends(require_permission("user:delete"))],
)
async def list_deleted_users(
    current_user: CurrentUser,
    db: DBSession,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    search: Optional[str] = Query(default=None),
) -> dict:
    svc = UserService(db)
    users, total = await svc.list_deleted_users(
        current_user.organization_id, search, page, page_size
    )
    paginated = PaginatedResponse.create(
        data=[UserResponse.from_orm_with_roles(u) for u in users],
        total=total,
        page=page,
        page_size=page_size,
    )
    return {"success": True, "message": "OK", "data": paginated}


@router.get(
    "/managers",
    response_model=StandardResponse[list[UserResponse]],
    summary="List managers (for sales-rep assignment)",
    dependencies=[Depends(require_permission("user:read"))],
)
async def list_managers(current_user: CurrentUser, db: DBSession) -> dict:
    """
    GET /api/v1/users/managers

    Lists active users holding the Manager role in the caller's organization —
    used by Admins when assigning Sales Representatives to a manager.
    """
    svc = UserService(db)
    managers = await svc.list_managers(current_user.organization_id)
    return {
        "success": True,
        "message": "Managers retrieved successfully.",
        "data": [UserResponse.from_orm_with_roles(u) for u in managers],
    }


@router.get(
    "/my-team",
    response_model=StandardResponse[list[UserResponse]],
    summary="My team (sales reps assigned to me)",
    dependencies=[Depends(require_role("manager"))],
)
async def list_my_team(current_user: CurrentUser, db: DBSession) -> dict:
    """
    GET /api/v1/users/my-team

    Manager-only. Returns only the Sales Representatives explicitly assigned
    to the calling manager by an admin — never the whole organization.
    """
    svc = UserService(db)
    reps = await svc.list_my_team(current_user.id, current_user.organization_id)
    return {
        "success": True,
        "message": "Team retrieved successfully.",
        "data": [UserResponse.from_orm_with_roles(u) for u in reps],
    }


@router.post(
    "",
    response_model=StandardResponse[UserResponse],
    status_code=status.HTTP_201_CREATED,
    summary="Create user",
    dependencies=[Depends(require_permission("user:create"))],
)
async def create_user(
    payload: UserCreateRequest,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    svc = UserService(db)
    user = await svc.create_user(payload, current_user.organization_id, current_user.id)
    return {"success": True, "message": "User created.", "data": UserResponse.from_orm_with_roles(user)}


@router.get(
    "/{user_id}",
    response_model=StandardResponse[UserResponse],
    summary="Get user by ID",
    dependencies=[Depends(require_permission("user:read"))],
)
async def get_user(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    svc = UserService(db)
    user = await svc.get_user(user_id, current_user.organization_id)
    return {"success": True, "message": "OK", "data": UserResponse.from_orm_with_roles(user)}


@router.put(
    "/{user_id}",
    response_model=StandardResponse[UserResponse],
    summary="Update user",
    dependencies=[Depends(require_permission("user:update"))],
)
async def update_user(
    user_id: UUID,
    payload: UserUpdateRequest,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    svc = UserService(db)
    user = await svc.update_user(user_id, current_user.organization_id, payload)
    return {"success": True, "message": "User updated.", "data": UserResponse.from_orm_with_roles(user)}


@router.delete(
    "/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete user (admin: permanent, manager: deactivate)",
    dependencies=[Depends(require_permission("user:delete"))],
)
async def delete_user(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> None:
    svc = UserService(db)
    await svc.delete_user(user_id, current_user.organization_id, current_user.id, current_user)


@router.post(
    "/{user_id}/activate",
    response_model=StandardResponse[UserResponse],
    summary="Activate user account",
    dependencies=[Depends(require_permission("user:activate"))],
)
async def activate_user(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    svc = UserService(db)
    user = await svc.activate_user(user_id, current_user.organization_id)
    return {"success": True, "message": "User activated.", "data": UserResponse.from_orm_with_roles(user)}


@router.post(
    "/{user_id}/deactivate",
    response_model=StandardResponse[UserResponse],
    summary="Deactivate user account",
    dependencies=[Depends(require_permission("user:deactivate"))],
)
async def deactivate_user(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    svc = UserService(db)
    user = await svc.deactivate_user(user_id, current_user.organization_id, current_user.id)
    return {"success": True, "message": "User deactivated.", "data": UserResponse.from_orm_with_roles(user)}


@router.post(
    "/{user_id}/roles",
    response_model=StandardResponse[UserResponse],
    summary="Assign roles to user",
    dependencies=[Depends(require_permission("user:manage_roles"))],
)
async def assign_roles(
    user_id: UUID,
    payload: UserRoleAssignRequest,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    svc = UserService(db)
    user = await svc.assign_role(
        user_id, current_user.organization_id, payload.role_id, current_user.id
    )
    invalidate_user_cache(str(user_id))
    return {"success": True, "message": "Role assigned.", "data": UserResponse.from_orm_with_roles(user)}


@router.post(
    "/{user_id}/manager",
    response_model=StandardResponse[UserResponse],
    summary="Assign sales rep to a manager",
    dependencies=[Depends(require_permission("user:manage_roles"))],
)
async def assign_manager(
    user_id: UUID,
    payload: ManagerAssignmentRequest,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    """
    POST /api/v1/users/{user_id}/manager  {manager_id: UUID}

    Admin only. Assigns the Sales Representative to the given manager.
    """
    svc = UserService(db)
    user = await svc.assign_manager(
        user_id,
        current_user.organization_id,
        payload.manager_id,
        current_user.id,
    )
    return {
        "success": True,
        "message": "Manager assigned.",
        "data": UserResponse.from_orm_with_roles(user),
    }


@router.delete(
    "/{user_id}/manager",
    response_model=StandardResponse[UserResponse],
    summary="Remove manager assignment from a sales rep",
    dependencies=[Depends(require_permission("user:manage_roles"))],
)
async def remove_manager(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    """
    DELETE /api/v1/users/{user_id}/manager

    Admin only. Unassigns the Sales Representative from their manager.
    """
    svc = UserService(db)
    user = await svc.remove_manager(user_id, current_user.organization_id, current_user.id)
    return {
        "success": True,
        "message": "Manager assignment removed.",
        "data": UserResponse.from_orm_with_roles(user),
    }


@router.post(
    "/{user_id}/restore",
    response_model=StandardResponse[UserResponse],
    summary="Restore archived user",
    dependencies=[Depends(require_permission("user:delete"))],
)
async def restore_user(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    svc = UserService(db)
    user = await svc.restore_user(user_id, current_user.organization_id, current_user.id)
    return {"success": True, "message": "User restored.", "data": UserResponse.from_orm_with_roles(user)}


@router.delete(
    "/{user_id}/permanent",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Permanently delete archived user (admin only)",
    dependencies=[Depends(require_permission("user:delete"))],
)
async def permanent_delete_user(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> None:
    svc = UserService(db)
    await svc.permanent_delete_user(user_id, current_user.organization_id, current_user.id)


@router.post(
    "/{user_id}/reset-password",
    response_model=StandardResponse[dict],
    summary="Reset user password (admin only)",
    dependencies=[Depends(require_permission("user:update"))],
)
async def reset_user_password(
    user_id: UUID,
    current_user: CurrentUser,
    db: DBSession,
) -> dict:
    from app.models.user import User
    import secrets
    import string

    if user_id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot reset your own password via this endpoint. Use change-password instead.",
        )

    svc = UserService(db)
    user = await svc.get_user(user_id, current_user.organization_id)

    new_password = ''.join(secrets.choice(string.ascii_letters + string.digits + "!@#$%") for _ in range(14))
    hashed = hash_password(new_password)

    repo = UserRepository(db)
    await repo.update(user, hashed_password=hashed)

    await svc.events.record_event(
        "USER_PASSWORD_RESET",
        organization_id=current_user.organization_id,
        actor_id=current_user.id,
        aggregate_type="user",
        aggregate_id=str(user.id),
        source="user_service",
        payload={"user_id": str(user.id), "reset_by": str(current_user.id)},
    )

    return {
        "success": True,
        "message": "Password reset successfully. The user will be notified via email.",
        "data": {"new_password": new_password},
    }

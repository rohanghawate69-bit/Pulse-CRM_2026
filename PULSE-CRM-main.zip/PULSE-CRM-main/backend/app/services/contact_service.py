﻿"""
Contact Management Service
"""
from typing import List, Optional, Tuple
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import DuplicateException, NotFoundException, BusinessRuleException, ForbiddenException
from app.core.logging import get_logger
from app.models.contact import Contact
from app.models.user import User
from app.repositories.contact_repository import ContactRepository
from app.repositories.company_repository import CompanyRepository
from app.services.timeline_engine_service import TimelineEngineService
from app.utils.enums import ActivityEntityType, ActivityType
from app.schemas.contact import ContactCreateRequest, ContactUpdateRequest

logger = get_logger(__name__)


class ContactService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.repo = ContactRepository(db)
        self.company_repo = CompanyRepository(db)
        self.timeline = TimelineEngineService(db)

    # ── RBAC helpers ────────────────────────────────────────────────────────

    def _has_elevated_access(self, user: User) -> bool:
        roles = {ur.role.name for ur in user.user_roles if ur.role}
        return bool({"admin", "manager"}.intersection(roles))

    def _assert_ownership(self, user: User, owner_id: Optional[UUID], created_by: Optional[UUID]) -> None:
        if self._has_elevated_access(user):
            return
        if owner_id != user.id and created_by != user.id:
            raise ForbiddenException("You do not have access to this contact.")

    def _scoped_owner_id(self, user: User) -> Optional[UUID]:
        """Returns owner_id filter for non-elevated users (sales_rep sees own only)."""
        return None if self._has_elevated_access(user) else user.id

    async def create(
        self,
        payload: ContactCreateRequest,
        organization_id: UUID,
        created_by: UUID,
    ) -> Contact:
        data = payload.model_dump(exclude_none=True)
        data["email"] = str(data["email"]).strip().lower()
        existing = await self.repo.get_by_email_in_org(data["email"], organization_id)
        if existing:
            raise DuplicateException("Contact", "email", data["email"])
        if data.get("phone") and await self.repo.get_by_phone_in_org(data["phone"], organization_id):
            raise DuplicateException("Contact", "phone", data["phone"])

        if payload.company_id:
            company = await self.company_repo.get_active_by_id(payload.company_id, organization_id)
            if not company:
                raise BusinessRuleException(
                    f"Company '{payload.company_id}' not found in your organization."
                )

        contact = await self.repo.create(
            **data,
            organization_id=organization_id,
            created_by=created_by,
        )
        await self.timeline.record_activity(
            organization_id=organization_id,
            created_by=created_by,
            entity_type=ActivityEntityType.CONTACT.value,
            entity_id=contact.id,
            action=ActivityType.CONTACT_CREATED.value,
            title="Contact created",
            description=f"Contact '{contact.full_name}' was created.",
            payload={"contact_id": str(contact.id), "email": contact.email},
            topic="contact",
        )
        logger.info("Contact created", extra={"contact_id": str(contact.id)})
        return contact

    async def list(
        self,
        user: User,
        search: Optional[str],
        company_id: Optional[UUID],
        page: int,
        page_size: int,
    ) -> Tuple[List[Contact], int]:
        effective_owner_id = self._scoped_owner_id(user)
        return await self.repo.list_by_organization(user.organization_id, search, company_id, page, page_size, owner_id=effective_owner_id)

    async def get(self, contact_id: UUID, user: User) -> Contact:
        contact = await self.repo.get_active_by_id(contact_id, user.organization_id)
        if not contact:
            raise NotFoundException("Contact", contact_id)
        self._assert_ownership(user, contact.owner_id, contact.created_by)
        return contact

    async def update(
        self,
        contact_id: UUID,
        user: User,
        payload: ContactUpdateRequest,
    ) -> Contact:
        contact = await self.get(contact_id, user)

        update_data = payload.model_dump(exclude_none=True)

        if "email" in update_data and update_data["email"]:
            update_data["email"] = str(update_data["email"]).strip().lower()
        if "email" in update_data and update_data["email"] != contact.email:
            existing = await self.repo.get_by_email_in_org(update_data["email"], user.organization_id)
            if existing and existing.id != contact_id:
                raise DuplicateException("Contact", "email", update_data["email"])
        if "phone" in update_data and update_data["phone"] != contact.phone:
            existing = await self.repo.get_by_phone_in_org(update_data["phone"], user.organization_id)
            if existing and existing.id != contact_id:
                raise DuplicateException("Contact", "phone", update_data["phone"])

        if "company_id" in update_data and update_data["company_id"]:
            company = await self.company_repo.get_active_by_id(update_data["company_id"], user.organization_id)
            if not company:
                raise BusinessRuleException("Company not found in your organization.")

        await self.repo.update(contact, **update_data)
        if update_data:
            await self.timeline.record_activity(
                organization_id=user.organization_id,
                created_by=contact.created_by,
                entity_type=ActivityEntityType.CONTACT.value,
                entity_id=contact.id,
                action="contact_updated",
                title="Contact updated",
                description=f"Contact '{contact.full_name}' was updated.",
                payload={"contact_id": str(contact.id), "changes": list(update_data.keys())},
                topic="contact",
            )
        return await self.get(contact_id, user)

    async def delete(self, contact_id: UUID, user: User) -> None:
        contact = await self.get(contact_id, user)
        organization_id = user.organization_id

        from app.models.deal import Deal
        from app.models.lead import Lead

        active_deals = (
            await self.db.execute(
                select(func.count()).select_from(Deal).where(
                    Deal.contact_id == contact_id,
                    Deal.is_deleted == False,
                )
            )
        ).scalar() or 0

        active_leads = (
            await self.db.execute(
                select(func.count()).select_from(Lead).where(
                    Lead.contact_id == contact_id,
                    Lead.is_deleted == False,
                )
            )
        ).scalar() or 0

        if active_deals > 0 or active_leads > 0:
            parts = []
            if active_deals:
                parts.append(f"{active_deals} deal{'s' if active_deals != 1 else ''}")
            if active_leads:
                parts.append(f"{active_leads} lead{'s' if active_leads != 1 else ''}")
            raise BusinessRuleException(
                f"Cannot delete contact '{contact.full_name}': linked to {', '.join(parts)}. "
                "Remove the contact from these records first, or delete them first."
            )

        await self.repo.soft_delete(contact)
        await self.timeline.record_activity(
            organization_id=organization_id,
            created_by=contact.created_by,
            entity_type=ActivityEntityType.CONTACT.value,
            entity_id=contact.id,
            action="contact_deleted",
            title="Contact deleted",
            description=f"Contact '{contact.full_name}' was deleted.",
            payload={"contact_id": str(contact.id)},
            topic="contact",
        )
        logger.info("Contact deleted", extra={"contact_id": str(contact_id)})

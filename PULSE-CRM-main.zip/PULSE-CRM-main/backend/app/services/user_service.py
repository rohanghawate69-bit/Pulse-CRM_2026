﻿"""
User Management Service
All user business logic — create, update, activate, deactivate, assign roles.
"""
from typing import List, Optional, Tuple
from uuid import UUID

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import (
    ConflictException,
    DuplicateException,
    NotFoundException,
    ForbiddenException,
)
from app.core.logging import get_logger
from app.core.security import hash_password
from app.models.user import User
from app.repositories.role_repository import RoleRepository
from app.repositories.user_repository import UserRepository
from app.schemas.user import UserCreateRequest, UserUpdateRequest, UserResponse
from app.services.event_service import EventService

logger = get_logger(__name__)


class UserService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.user_repo = UserRepository(db)
        self.role_repo = RoleRepository(db)
        self.events = EventService(db)

    def _is_admin(self, user: User) -> bool:
        """Check if user has admin role."""
        return any(ur.role.name == "admin" for ur in user.user_roles if ur.role)

    async def create_user(
        self,
        payload: UserCreateRequest,
        organization_id: UUID,
        created_by: UUID,
    ) -> User:
        existing = await self.user_repo.get_by_email_any(payload.email.lower())
        if existing:
            raise DuplicateException("User", "email", payload.email)

        try:
            user = await self.user_repo.create(
                email=payload.email.lower(),
                full_name=payload.full_name.strip(),
                hashed_password=hash_password(payload.password),
                phone=payload.phone,
                job_title=payload.job_title,
                timezone=payload.timezone,
                locale=payload.locale,
                organization_id=organization_id,
                is_verified=True,
            )
        except IntegrityError:
            await self.db.rollback()
            raise DuplicateException("User", "email", payload.email)

        if payload.role_id:
            await self.user_repo.assign_role(user, payload.role_id, created_by)

        user = await self.user_repo.get_by_id_with_roles(user.id)
        logger.info("User created", extra={"user_id": str(user.id), "created_by": str(created_by)})
        await self.events.record_event(
            "USER_CREATED",
            organization_id=organization_id,
            actor_id=created_by,
            aggregate_type="user",
            aggregate_id=str(user.id),
            source="user_service",
            payload={
                "user_id": str(user.id),
                "email": user.email,
                "full_name": user.full_name,
                "role_id": str(payload.role_id) if payload.role_id else None,
            },
        )
        return user

    async def list_users(
        self,
        organization_id: UUID,
        search: Optional[str],
        page: int,
        page_size: int,
    ) -> Tuple[List[User], int]:
        return await self.user_repo.list_by_organization(
            organization_id, search, page, page_size
        )

    async def get_user(self, user_id: UUID, organization_id: UUID) -> User:
        user = await self.user_repo.get_by_id_with_roles(user_id)
        if not user or user.organization_id != organization_id:
            raise NotFoundException("User", user_id)
        return user

    async def update_user(
        self,
        user_id: UUID,
        organization_id: UUID,
        payload: UserUpdateRequest,
    ) -> User:
        user = await self.get_user(user_id, organization_id)
        update_data = payload.model_dump(exclude_none=True)
        await self.user_repo.update(user, **update_data)
        updated = await self.user_repo.get_by_id_with_roles(user.id)
        if update_data:
            await self.events.record_event(
                "USER_UPDATED",
                organization_id=organization_id,
                actor_id=user.id,
                aggregate_type="user",
                aggregate_id=str(user.id),
                source="user_service",
                payload={"user_id": str(user.id), "changes": list(update_data.keys())},
            )
        return updated

    async def activate_user(self, user_id: UUID, organization_id: UUID) -> User:
        user = await self.get_user(user_id, organization_id)
        if user.is_active:
            raise ConflictException("User is already active.")
        await self.user_repo.update(user, is_active=True)
        await self.events.record_event(
            "USER_ACTIVATED",
            organization_id=organization_id,
            actor_id=user.id,
            aggregate_type="user",
            aggregate_id=str(user.id),
            source="user_service",
            payload={"user_id": str(user.id)},
        )
        return user

    async def deactivate_user(self, user_id: UUID, organization_id: UUID, requestor_id: UUID) -> User:
        if user_id == requestor_id:
            raise ForbiddenException("You cannot deactivate your own account.")
        user = await self.get_user(user_id, organization_id)
        if not user.is_active:
            raise ConflictException("User is already inactive.")
        await self.user_repo.update(user, is_active=False)
        await self.events.record_event(
            "USER_DEACTIVATED",
            organization_id=organization_id,
            actor_id=requestor_id,
            aggregate_type="user",
            aggregate_id=str(user.id),
            source="user_service",
            payload={"user_id": str(user.id), "requestor_id": str(requestor_id)},
        )
        return user

    async def assign_role(
        self,
        user_id: UUID,
        organization_id: UUID,
        role_id: UUID,
        assigned_by: UUID,
    ) -> User:
        user = await self.get_user(user_id, organization_id)
        await self.user_repo.assign_role(user, role_id, assigned_by)
        updated = await self.user_repo.get_by_id_with_roles(user.id)
        await self.events.record_event(
            "USER_ROLE_ASSIGNED",
            organization_id=organization_id,
            actor_id=assigned_by,
            aggregate_type="user",
            aggregate_id=str(user.id),
            source="user_service",
            payload={
                "user_id": str(user.id),
                "role_id": str(role_id),
                "assigned_by": str(assigned_by),
            },
        )
        return updated

    async def assign_manager(
        self,
        user_id: UUID,
        organization_id: UUID,
        manager_id: UUID,
        assigned_by: UUID,
    ) -> User:
        """Assign a Sales Representative to a Manager (admin only, enforced at route level)."""
        user = await self.get_user(user_id, organization_id)
        role_names = {ur.role.name for ur in user.user_roles if ur.role}
        if "sales_rep" not in role_names:
            raise ConflictException(
                "Only users with the Sales Representative role can be assigned to a manager."
            )
        if user.manager_id == manager_id:
            raise ConflictException("User is already assigned to this manager.")
        if manager_id == user_id:
            raise ForbiddenException("A user cannot be assigned to themselves.")
        if not user.is_active:
            raise ConflictException("Cannot assign an inactive sales rep to a manager.")

        manager = await self.user_repo.get_by_id_any(manager_id)
        if not manager or manager.organization_id != organization_id or manager.is_deleted:
            raise NotFoundException("Manager", manager_id)
        if not manager.is_active:
            raise ConflictException("Manager account is inactive.")
        manager_roles = {ur.role.name for ur in manager.user_roles if ur.role}
        if "manager" not in manager_roles:
            raise ConflictException("The assigned user must hold the Manager role.")

        await self.user_repo.update(user, manager_id=manager_id)
        updated = await self.user_repo.get_by_id_with_roles(user.id)
        await self.events.record_event(
            "USER_MANAGER_ASSIGNED",
            organization_id=organization_id,
            actor_id=assigned_by,
            aggregate_type="user",
            aggregate_id=str(user.id),
            source="user_service",
            payload={
                "user_id": str(user.id),
                "manager_id": str(manager_id),
                "assigned_by": str(assigned_by),
            },
        )
        return updated

    async def remove_manager(
        self,
        user_id: UUID,
        organization_id: UUID,
        requestor_id: UUID,
    ) -> User:
        """Remove the manager assignment from a sales rep (admin only)."""
        user = await self.get_user(user_id, organization_id)
        if not user.manager_id:
            raise ConflictException("User has no assigned manager.")
        await self.user_repo.update(user, manager_id=None)
        updated = await self.user_repo.get_by_id_with_roles(user.id)
        await self.events.record_event(
            "USER_MANAGER_REMOVED",
            organization_id=organization_id,
            actor_id=requestor_id,
            aggregate_type="user",
            aggregate_id=str(user.id),
            source="user_service",
            payload={"user_id": str(user.id), "requestor_id": str(requestor_id)},
        )
        return updated

    async def list_managers(self, organization_id: UUID) -> List[User]:
        """Active manager-role users in the org (admin assignment picker)."""
        return await self.user_repo.list_managers(organization_id)

    async def list_my_team(self, manager_id: UUID, organization_id: UUID) -> List[User]:
        """Sales reps assigned to the given manager — manager-scoped team view."""
        return await self.user_repo.list_team_reps(manager_id, organization_id)

    async def delete_user(self, user_id: UUID, organization_id: UUID, requestor_id: UUID, requestor: User) -> None:
        """Role-based delete: admin = hard delete, manager = soft delete (deactivate)."""
        if user_id == requestor_id:
            raise ForbiddenException("You cannot delete your own account.")
        user = await self.get_user(user_id, organization_id)

        if self._is_admin(requestor):
            await self.user_repo.delete(user)
            logger.info("User hard-deleted by admin", extra={"user_id": str(user_id), "requestor_id": str(requestor_id)})
            await self.events.record_event(
                "USER_PERMANENTLY_DELETED",
                organization_id=organization_id,
                actor_id=requestor_id,
                aggregate_type="user",
                aggregate_id=str(user_id),
                source="user_service",
                payload={"user_id": str(user_id), "requestor_id": str(requestor_id)},
            )
        else:
            await self.user_repo.soft_delete(user)
            logger.info("User soft-deleted (deactivated)", extra={"user_id": str(user_id), "requestor_id": str(requestor_id)})
            await self.events.record_event(
                "USER_DEACTIVATED",
                organization_id=organization_id,
                actor_id=requestor_id,
                aggregate_type="user",
                aggregate_id=str(user_id),
                source="user_service",
                payload={"user_id": str(user_id), "requestor_id": str(requestor_id)},
            )

    async def list_deleted_users(
        self,
        organization_id: UUID,
        search: Optional[str],
        page: int,
        page_size: int,
    ) -> Tuple[List[User], int]:
        """List soft-deleted (archived) users — admin only."""
        return await self.user_repo.list_deleted_by_organization(
            organization_id, search, page, page_size
        )

    async def restore_user(self, user_id: UUID, organization_id: UUID, requestor_id: UUID) -> User:
        """Restore a soft-deleted user — admin only."""
        user = await self.user_repo.get_by_id_any(user_id)
        if not user or user.organization_id != organization_id:
            raise NotFoundException("User", user_id)
        if not user.is_deleted:
            raise ConflictException("User is not archived.")
        await self.user_repo.update(user, is_deleted=False, is_active=True)
        restored = await self.user_repo.get_by_id_with_roles(user.id)
        logger.info("User restored", extra={"user_id": str(user_id), "requestor_id": str(requestor_id)})
        await self.events.record_event(
            "USER_RESTORED",
            organization_id=organization_id,
            actor_id=requestor_id,
            aggregate_type="user",
            aggregate_id=str(user_id),
            source="user_service",
            payload={"user_id": str(user_id), "requestor_id": str(requestor_id)},
        )
        return restored

    async def permanent_delete_user(self, user_id: UUID, organization_id: UUID, requestor_id: UUID) -> None:
        """Permanently delete a soft-deleted user — admin only. Frees up the email."""
        user = await self.user_repo.get_by_id_any(user_id)
        if not user or user.organization_id != organization_id:
            raise NotFoundException("User", user_id)
        if not user.is_deleted:
            raise ConflictException("User must be archived before permanent deletion.")
        await self.user_repo.delete(user)
        logger.info("User permanently deleted", extra={"user_id": str(user_id), "requestor_id": str(requestor_id)})
        await self.events.record_event(
            "USER_PERMANENTLY_DELETED",
            organization_id=organization_id,
            actor_id=requestor_id,
            aggregate_type="user",
            aggregate_id=str(user_id),
            source="user_service",
            payload={"user_id": str(user_id), "requestor_id": str(requestor_id)},
        )

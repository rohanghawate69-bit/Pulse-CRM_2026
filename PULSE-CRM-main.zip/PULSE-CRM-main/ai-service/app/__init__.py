"""AI microservice package."""
